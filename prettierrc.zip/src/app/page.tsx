import Link from "next/link";

export default function Home() {
  return (
    <main className="">
      Landing Screen <Link href='/login'>Login</Link>
    </main>
  );
}
