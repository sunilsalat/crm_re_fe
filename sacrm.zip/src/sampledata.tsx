export const LeadsDataById = {
    leadID:"213543",
    leadTimeLine :[
        {
            timeStamp:"20 June 2024",
            reminderDate:"22 June 2024",
            reminderMessage:"Schedule new site visit"
        },

        {
            timeStamp:"20 June 2024",
            reminderDate:"22 June 2024",
            reminderMessage:"Schedule new site visit"
        },

        {
            timeStamp:"20 June 2024",
            reminderDate:"22 June 2024",
            reminderMessage:"Schedule new site visit"
        },

        {
            timeStamp:"20 June 2024",
            reminderDate:"22 June 2024",
            reminderMessage:"Schedule new site visit"
        },
    ]
}


export const LeadsData = [
    
    {
        leadID:"213543",
        timeStamp:"20 June 2024",
        reminderDate:"22 June 2024",
        reminderMessage:"Schedule new site visit"
    }
]