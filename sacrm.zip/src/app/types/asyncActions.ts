export const loginType = 'auth/userLogin';
export const registerType = 'auth/userRegister';
export const logoutType = 'auth/userLogout';
