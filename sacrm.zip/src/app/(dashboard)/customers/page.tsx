import React from 'react'

const page = () => {
  return (
    <div>Customers page</div>
  )
}

export default page
