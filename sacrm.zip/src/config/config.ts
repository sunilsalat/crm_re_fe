export const baseUrl = 'http://localhost:8000/api/v1/';

export const loginUrl = `${baseUrl}user/login`;
export const registerUrl = `${baseUrl}user/register`;
export const logoutUrl = `${baseUrl}user/logout`;
