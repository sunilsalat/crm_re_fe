export const FIRST_NAME = 'firstName';
export const LAST_NAME = 'lastName';
export const EMAIL = 'email';
export const PHONE = 'phone';
export const PASSWORD = 'password';
export const CONFIRM_PASSWORD = 'confirmPassword';
